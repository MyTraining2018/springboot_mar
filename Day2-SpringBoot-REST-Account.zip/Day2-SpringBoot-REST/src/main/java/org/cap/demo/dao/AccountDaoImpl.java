package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Account;
import org.springframework.stereotype.Repository;

@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao{
	
	private static AtomicInteger accountId=new AtomicInteger(1001);
	private static List<Account> accounts=dummyDbAccounts();
	
	private static List<Account> dummyDbAccounts(){
		List<Account> accounts=new ArrayList<>();
		
		accounts.add(new Account(accountId.getAndIncrement(), "Tom", new Date(), "Savings", 23000));
		accounts.add(new Account(accountId.getAndIncrement(), "Jerry", new Date(), "Current", 2300));
		accounts.add(new Account(accountId.getAndIncrement(), "Jack", new Date(2017,03,12), "CarLoan", 450000));
		accounts.add(new Account(accountId.getAndIncrement(), "Emi", new Date(), "HomeLoan", 1200000));
		accounts.add(new Account(accountId.getAndIncrement(), "John", new Date(), "Savings", 5000));
		
		return accounts;
	}

	@Override
	public List<Account> getAllAccounts() {
		
		return accounts;
	}

	@Override
	public Account findAccount(Integer accountId) {
		
		for(Account account:accounts) {
			if(account.getAccountId()==accountId) {
				return account;
			}
		}
		return null;
	}

	@Override
	public List<Account> deleteAccount(Integer accountId) {
		boolean flag=false;
		
		Iterator<Account> iterator= accounts.iterator();
		while(iterator.hasNext()) {
			Account account= iterator.next();
			if(account.getAccountId()==accountId) {
				flag=true;
				iterator.remove();
				break;
			}
		}
		
		if(flag==false)
			return null;
		else
			
		return accounts;
	}

	@Override
	public List<Account> createAccount(Account account) {
		
		accounts.add(account);
		
		return accounts;
	}

}
