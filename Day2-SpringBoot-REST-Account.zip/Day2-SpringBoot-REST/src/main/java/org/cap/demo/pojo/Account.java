package org.cap.demo.pojo;

import java.util.Date;

public class Account {
	
	private int accountId;
	private String accountName;
	private Date openDate;
	private String accountType;
	private double balance;
	
	public Account() {
		
	}
	
	public Account(int accountId, String accountName, Date openDate, String accountType, double balance) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.openDate = openDate;
		this.accountType = accountType;
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Date getOpenDate() {
		return openDate;
	}
	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountName=" + accountName + ", openDate=" + openDate
				+ ", accountType=" + accountType + ", balance=" + balance + "]";
	}
	
	

}
