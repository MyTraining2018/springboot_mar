package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Account;

public interface IAccountService {
	public List<Account> getAllAccounts();

	public Account findAccount(Integer accountId);

	public List<Account> deleteAccount(Integer accountId);

	public List<Account> createAccount(Account account);
	
	public List<Account> updateAccount(Account account);
	
	public List<Account> findByAccountType(String accountType);
	
	public List<Account> findByAccountTypeAndBalance(String accountType,
			double balance);
	public List<Account> fetchMyAccounts(double balance);
}
