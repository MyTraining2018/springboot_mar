package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAccountDao;
import org.cap.demo.pojo.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountService")
public class AccountServiceImpl implements IAccountService{

	@Autowired
	private IAccountDao accountDao;
	
	@Override
	public List<Account> getAllAccounts() {
		
		return accountDao.getAllAccounts();
	}

	@Override
	public Account findAccount(Integer accountId) {
		// TODO Auto-generated method stub
		return accountDao.findAccount(accountId);
	}

	@Override
	public List<Account> deleteAccount(Integer accountId) {
		// TODO Auto-generated method stub
		return accountDao.deleteAccount(accountId);
	}

	@Override
	public List<Account> createAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.createAccount(account);
	}

	@Override
	public List<Account> updateAccount(Account account) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> findByAccountType(String accountType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> findByAccountTypeAndBalance(String accountType, double balance) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> fetchMyAccounts(double balance) {
		// TODO Auto-generated method stub
		return null;
	}

}
