package org.cap.demo.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.cap.demo.pojo.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository("accountDbDao")
@Transactional
public interface IAccountDBDao 
	extends  JpaRepository<Account, Integer>{
	
	public List<Account> findByAccountType(String accountType);
	public List<Account> findByAccountTypeAndBalance(String accountType,
			double balance);
	
	public List<Account> findByAccountTypeAndBalanceOrderByAccountName(String accountType,
			double balance);
	
	//JPQL Query
	@Query("select acc from Account acc where balance>?")
	public List<Account> fetchMyAccounts(double balance);

}
