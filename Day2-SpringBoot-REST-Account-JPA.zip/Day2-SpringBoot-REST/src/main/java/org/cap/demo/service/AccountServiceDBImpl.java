package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IAccountDBDao;
import org.cap.demo.pojo.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("accountDbService")
public class AccountServiceDBImpl implements IAccountService{

	@Autowired
	private IAccountDBDao accountDbDao;
	
	@Override
	public List<Account> getAllAccounts() {
		
		return accountDbDao.findAll();
	}

	@Override
	public Account findAccount(Integer accountId) {
		
		return accountDbDao.findOne(accountId);
	}

	@Override
	public List<Account> deleteAccount(Integer accountId) {
		accountDbDao.delete(accountId);
		return accountDbDao.findAll();
	}

	@Override
	public List<Account> createAccount(Account account) {
		accountDbDao.save(account);
		return accountDbDao.findAll();
	}

	@Override
	public List<Account> updateAccount(Account account) {
		accountDbDao.save(account);
		return accountDbDao.findAll();
	}

	@Override
	public List<Account> findByAccountType(String accountType) {
		
		return accountDbDao.findByAccountType(accountType);
	}

	@Override
	public List<Account> findByAccountTypeAndBalance(String accountType, double balance) {
		// TODO Auto-generated method stub
		return accountDbDao.findByAccountTypeAndBalance(accountType, balance);
	}

	@Override
	public List<Account> fetchMyAccounts(double balance) {
		// TODO Auto-generated method stub
		return accountDbDao.fetchMyAccounts(balance);
	}

}
