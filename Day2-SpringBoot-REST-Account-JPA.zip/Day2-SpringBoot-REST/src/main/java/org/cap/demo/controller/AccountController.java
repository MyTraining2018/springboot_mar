package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.pojo.Account;
import org.cap.demo.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AccountController {
	
	@Autowired
	//private IAccountService accountService;
	private IAccountService accountDbService;
	
	@GetMapping("/accountbal/{balance}")
	public ResponseEntity<List<Account>> findByAccountBalance(
			@PathVariable("balance") double balance){
		List<Account> accounts=accountDbService.fetchMyAccounts(balance);
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! No Account details Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	
	
	@GetMapping("/accounttype/{acctype}")
	public ResponseEntity<List<Account>> findByAccounttype(
			@PathVariable("acctype") String accountType){
		List<Account> accounts=accountDbService.findByAccountType(accountType);
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! No Account details Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	@GetMapping("/accounttype/{acctype}/{balance}")
	public ResponseEntity<List<Account>> findByAccounttypeAndBalance(
			@PathVariable("acctype") String accountType,
			@PathVariable("balance")double balance){
		List<Account> accounts=accountDbService.findByAccountTypeAndBalance(accountType, balance);
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! No Account details Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	
	
	
	
	
	///--------------------CRUD OPerations----------------------
	
	
	@GetMapping("/accounts")
	public ResponseEntity<List<Account>> getAllAccounts(){
		List<Account> accounts=accountDbService.getAllAccounts();
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! No Account details Available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	@GetMapping("/accounts/{accountNo}")
	public ResponseEntity<Account> findAccount(
			@PathVariable("accountNo") Integer accountId){
		
		Account account=accountDbService.findAccount(accountId);
		
		if(account==null)
			return new ResponseEntity("Sorry!Account Number not found!", HttpStatus.NOT_FOUND);
		
		
		return new ResponseEntity<Account>(account, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/accounts/{accountNo}")
	public ResponseEntity<List<Account>> deleteAccount(
			@PathVariable("accountNo") Integer accountId){
		
		List<Account> account=accountDbService.deleteAccount(accountId);
		
		if(account==null)
			return new ResponseEntity("Sorry!Account Number not found!", HttpStatus.NOT_FOUND);
		
		
		return new ResponseEntity<List<Account>>(account, HttpStatus.OK);
	}
	
	
	@PostMapping("/accounts")
	public ResponseEntity<List<Account>> createAccount(
			@RequestBody Account account){
		
		List<Account> accounts=accountDbService.createAccount(account);
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! Account number conflict!", HttpStatus.CONFLICT);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	

	@PutMapping("/accounts")
	public ResponseEntity<List<Account>> updateAccount(
			@RequestBody Account account){
		
		List<Account> accounts=accountDbService.updateAccount(account);
		if(accounts.isEmpty() || accounts==null)
			return new ResponseEntity("Sorry! Account number conflict!", HttpStatus.CONFLICT);
		
		return new ResponseEntity<List<Account>>(accounts, HttpStatus.OK);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
