package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IProductDao;
import org.cap.demo.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//@Service("productService")
public class ProductServiceImpl  implements IProductService{

	@Autowired
	private IProductDao productDao;
	
	@Override
	public List<Product> getProducts() {
		return productDao.getProducts();
	}

	@Override
	public Product findProduct(int productId) {
		
		return productDao.findProduct(productId);
	}

	@Override
	public List<Product> deleteProduct(int productId) {
		
		return productDao.deleteProduct(productId);
	}

	@Override
	public List<Product> createProduct(Product product) {
		
		return productDao.createProduct(product);
	}

}
