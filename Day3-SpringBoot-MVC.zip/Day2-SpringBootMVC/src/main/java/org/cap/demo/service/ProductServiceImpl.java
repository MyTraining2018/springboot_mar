package org.cap.demo.service;

import java.util.List;

import org.cap.demo.dao.IProductDaoDB;
import org.cap.demo.pojo.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("productService")
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductDaoDB productDaoDb;
	
	@Override
	public List<Product> getProducts() {
		
		return productDaoDb.findAll();
	}

	@Override
	public Product findProduct(int productId) {
		
		return productDaoDb.findOne(productId);
	}

	@Override
	public List<Product> deleteProduct(int productId) {
		productDaoDb.delete(productId);
		return productDaoDb.findAll();
	}

	@Override
	public List<Product> createProduct(Product product) {
		productDaoDb.save(product);
		return productDaoDb.findAll();
	}

}
