package org.cap.demo.dao;
import javax.transaction.Transactional;
import org.cap.demo.pojo.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("productDaoDb")
@Transactional
public interface IProductDaoDB extends JpaRepository<Product, Integer>{

}
