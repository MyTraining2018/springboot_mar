package org.cap.demo.service;

public interface ILoginService {
	
	public boolean validateUser(String userName, String userPwd);

}
