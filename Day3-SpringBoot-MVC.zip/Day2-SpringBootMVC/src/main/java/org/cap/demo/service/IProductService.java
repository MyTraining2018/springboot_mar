package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Product;

public interface IProductService {
	public List<Product> getProducts();
	public Product findProduct(int productId) ;
	public List<Product> deleteProduct(int productId);
	public List<Product> createProduct(Product product);
		
		
}
