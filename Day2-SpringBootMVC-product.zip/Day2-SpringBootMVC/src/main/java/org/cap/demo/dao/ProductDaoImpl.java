package org.cap.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.demo.pojo.Product;
import org.springframework.stereotype.Repository;

@Repository("productDao")
public class ProductDaoImpl implements IProductDao {
	
	private static AtomicInteger productId=new AtomicInteger(1); 
	private static List<Product> products=dummyList();
	
	public static List<Product> dummyList() {
		List<Product> list=new ArrayList<>();
		list.add(new Product(productId.getAndIncrement(), "Lux", "Beauty Soap", 34, 56.89));
		list.add(new Product(productId.getAndIncrement(), "Lifebouy", "Soap", 12, 67.89));
		list.add(new Product(productId.getAndIncrement(), "Pears", "SkinCare", 34, 23.45));
		list.add(new Product(productId.getAndIncrement(), "Medimix", "Beauty Soap", 90, 12.89));
		list.add(new Product(productId.getAndIncrement(), "hammam", "Beauty Soap", 67, 12.89));
		return list;
	}
	
	

	@Override
	public List<Product> getProducts() {
		
		return products;
	}

}
