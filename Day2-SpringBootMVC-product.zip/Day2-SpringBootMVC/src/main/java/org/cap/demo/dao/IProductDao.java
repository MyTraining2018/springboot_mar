package org.cap.demo.dao;

import java.util.List;

import org.cap.demo.pojo.Product;

public interface IProductDao {
	
	public List<Product> getProducts();

}
