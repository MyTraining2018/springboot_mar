package org.cap.demo.service;

import org.springframework.stereotype.Service;

@Service("loginService")
public class LoginServiceImpl implements ILoginService{

	@Override
	public boolean validateUser(String userName, String userPwd) {
		if(userName.equals("tom") && 
				userPwd.equals("tom123"))
			return true;
		return false;
	}

}
