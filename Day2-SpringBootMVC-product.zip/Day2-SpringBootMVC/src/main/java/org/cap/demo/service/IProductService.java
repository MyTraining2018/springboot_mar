package org.cap.demo.service;

import java.util.List;

import org.cap.demo.pojo.Product;

public interface IProductService {
	public List<Product> getProducts();
		
}
