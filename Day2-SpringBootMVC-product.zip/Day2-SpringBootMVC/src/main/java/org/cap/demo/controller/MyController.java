package org.cap.demo.controller;

import org.cap.demo.service.ILoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
	
	@Autowired
	private ILoginService loginService;

	@RequestMapping("/hello")
	public ModelAndView sayHello() {
		return new ModelAndView("helloPage", "msg", "SpringBoot MVC!");
	}
	
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST)
	public String validateLogin(@RequestParam("userName") String userName,
				@RequestParam("userPwd") String userPwd) {
		if(loginService.validateUser(userName, userPwd))
			return "success";
		else
			return "redirect:/";
		
		
	}
}
