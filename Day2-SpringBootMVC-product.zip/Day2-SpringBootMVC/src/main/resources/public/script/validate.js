function validateAllFields(){
	var userName=loginfrm.userName.value;
	var userPwd=loginfrm.userPwd.value;
	var flag=false;
	
	if(userName==""||userName==null){
		flag=false;
		document.getElementById('errUserName').innerHTML=
			"* Please Enter USerName.";
	}else if(userPwd==""||userPwd==null){
		flag=false;
		document.getElementById('errUserName').innerHTML="";
		document.getElementById('errUserPwd').innerHTML=
			"* Please Enter Password.";
	}else{
		flag=true;
		}
	return flag;
}